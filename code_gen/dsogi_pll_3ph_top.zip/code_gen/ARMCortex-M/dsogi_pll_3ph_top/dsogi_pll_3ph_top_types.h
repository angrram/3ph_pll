/*
 * File: dsogi_pll_3ph_top_types.h
 *
 * Code generated for Simulink model 'dsogi_pll_3ph_top'.
 *
 * Model version                  : 1.8
 * Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
 * C/C++ source code generated on : Wed Jul  3 20:17:15 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. Traceability
 *    3. Debugging
 * Validation result: Not run
 */

#ifndef RTW_HEADER_dsogi_pll_3ph_top_types_h_
#define RTW_HEADER_dsogi_pll_3ph_top_types_h_

/* Forward declaration for rtModel */
typedef struct tag_RTM_dsogi_pll_3ph_top_T RT_MODEL_dsogi_pll_3ph_top_T;

#endif                               /* RTW_HEADER_dsogi_pll_3ph_top_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
