/*
 * File: dsogi_pll_3ph_data.c
 *
 * Code generated for Simulink model 'dsogi_pll_3ph'.
 *
 * Model version                  : 1.148
 * Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
 * C/C++ source code generated on : Sun Jul 14 17:58:09 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. Traceability
 *    3. Debugging
 * Validation result: Not run
 */

#include "dsogi_pll_3ph_private.h"

/* Invariant block signals (default storage) */
const ConstB_dsogi_pll_3ph_h_T dsogi_pll_3ph_ConstB = {
  314.15926535897933,                  /* '<S33>/Constant' */
  0.0                                  /* '<S24>/Constant' */
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
