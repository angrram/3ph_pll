/*
 * File: dsogi_pll_3ph_private.h
 *
 * Code generated for Simulink model 'dsogi_pll_3ph'.
 *
 * Model version                  : 1.148
 * Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
 * C/C++ source code generated on : Sun Jul 14 17:58:09 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. Traceability
 *    3. Debugging
 * Validation result: Not run
 */

#ifndef RTW_HEADER_dsogi_pll_3ph_private_h_
#define RTW_HEADER_dsogi_pll_3ph_private_h_
#include <stdbool.h>
#include <stdint.h>
#include "complex_types.h"
#include "dsogi_pll_3ph.h"
#include "dsogi_pll_3ph_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         (*((rtm)->errorStatus))
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    (*((rtm)->errorStatus) = (val))
#endif

#ifndef rtmGetErrorStatusPointer
#define rtmGetErrorStatusPointer(rtm)  (rtm)->errorStatus
#endif

#ifndef rtmSetErrorStatusPointer
#define rtmSetErrorStatusPointer(rtm, val) ((rtm)->errorStatus = (val))
#endif

/* Invariant block signals (default storage) */
extern const ConstB_dsogi_pll_3ph_h_T dsogi_pll_3ph_ConstB;

#endif                                 /* RTW_HEADER_dsogi_pll_3ph_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
